﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ShoppingCart.Migrations
{
    public partial class initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "AppUsers",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PasswordHash = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Role = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AppUsers", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Products",
                columns: table => new
                {
                    ProductId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ProductName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Unit = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Price = table.Column<float>(type: "real", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Products", x => x.ProductId);
                });

            migrationBuilder.CreateTable(
                name: "Cart",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AppUserid = table.Column<int>(type: "int", nullable: false),
                    FinalisedDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Total = table.Column<double>(type: "float", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cart", x => x.id);
                    table.ForeignKey(
                        name: "FK_Cart_AppUsers_AppUserid",
                        column: x => x.AppUserid,
                        principalTable: "AppUsers",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "CartItem",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Cartid = table.Column<int>(type: "int", nullable: false),
                    Productid = table.Column<int>(type: "int", nullable: false),
                    Quantity = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CartItem", x => x.id);
                    table.ForeignKey(
                        name: "FK_CartItem_Cart_Cartid",
                        column: x => x.Cartid,
                        principalTable: "Cart",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_CartItem_Products_Productid",
                        column: x => x.Productid,
                        principalTable: "Products",
                        principalColumn: "ProductId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "AppUsers",
                columns: new[] { "id", "PasswordHash", "Role", "UserName" },
                values: new object[] { 1, "$2a$11$xB43RQbhYu397u2SArnzhOEw9eqRj9yLXw7QiILTE0VEwwVPgzVhy", 1, "admin" });

            migrationBuilder.InsertData(
                table: "Products",
                columns: new[] { "ProductId", "Price", "ProductName", "Unit" },
                values: new object[,]
                {
                    { 1, 5.5f, "Granny Smith Apples", "1kg" },
                    { 2, 5.9f, "Fresh tomatoes", "500g" },
                    { 3, 6.6f, "Watermelon", "Whole" },
                    { 4, 1.9f, "Cucumber", "1 whole" },
                    { 5, 4f, "Red potato washed", "1kg" },
                    { 6, 4.9f, "Red tipped bananas", "1kg" },
                    { 7, 3.5f, "Red onion", "1kg" },
                    { 8, 2f, "Carrots", "1kg" },
                    { 9, 2.5f, "Iceburg Lettuce", "1" },
                    { 10, 3.7f, "Helga's Wholemeal", "1" },
                    { 11, 7.5f, "Free range chicken", "1kg" },
                    { 12, 3.6f, "Manning Valley 6-pk", "6 eggs" },
                    { 13, 2.9f, "A2 light milk", "1 litre" },
                    { 14, 1.5f, "Chobani Strawberry Yoghurt", "1" },
                    { 15, 5f, "Lurpak Salted Blend", "250g" },
                    { 16, 4f, "Bega Farmers Tasty", "250g" },
                    { 17, 4.2f, "Babybel Mini", "100g" },
                    { 18, 8f, "Cobram EVOO", "375ml" },
                    { 19, 2.5f, "Heinz Tomato Soup", "535g" },
                    { 20, 1.5f, "John West Tuna can", "95g" },
                    { 21, 5f, "Cadbury Dairy Milk", "200g" },
                    { 22, 2.85f, "Coca Cola", "2 litre" },
                    { 23, 3.29f, "Smith's Original Share Pack Crisps", "170g" },
                    { 24, 4.5f, "Birds Eye Fish Fingers", "375g" },
                    { 25, 6f, "Berri Orange Juice", "2 litre" },
                    { 26, 6f, "Vegemite", "380g" },
                    { 27, 2f, "Cheddar Shapes", "175g" },
                    { 28, 3.5f, "Colgate Total Toothpaste Original", "110g" },
                    { 29, 4f, "Milo Chocolate Malt", "200g" },
                    { 30, 5.33f, "Weet Bix Saniatarium Organic", "750g" },
                    { 31, 4.25f, "Lindt Excellence 70% Cocoa Block", "100g" },
                    { 32, 3.65f, "Original Tim Tams Choclate", "200g" },
                    { 33, 4.3f, "Philadelphia Original Cream Cheese", "250g" },
                    { 34, 6f, "Moccana Classic Instant Medium Roast", "100g" },
                    { 35, 7.35f, "Capilano Squeezable Honey", "500g" },
                    { 36, 4f, "Nutella jar", "400g" },
                    { 37, 2.85f, "Arnott's Scotch Finger", "250g" },
                    { 38, 5f, "South Cape Greek Feta", "200g" },
                    { 39, 4.5f, "Sacla Pasta Tomato Basil Sauce", "420g" },
                    { 40, 3f, "Primo English Ham", "100g" },
                    { 41, 5f, "Primo Short cut rindless Bacon", "175g" }
                });

            migrationBuilder.InsertData(
                table: "Products",
                columns: new[] { "ProductId", "Price", "ProductName", "Unit" },
                values: new object[] { 42, 3.25f, "Golden Circle Pineapple Pieces in natural juice", "440g" });

            migrationBuilder.InsertData(
                table: "Products",
                columns: new[] { "ProductId", "Price", "ProductName", "Unit" },
                values: new object[] { 43, 1.95f, "San Remo Linguine Pasta No 1", "500g" });

            migrationBuilder.CreateIndex(
                name: "IX_Cart_AppUserid",
                table: "Cart",
                column: "AppUserid");

            migrationBuilder.CreateIndex(
                name: "IX_CartItem_Cartid",
                table: "CartItem",
                column: "Cartid");

            migrationBuilder.CreateIndex(
                name: "IX_CartItem_Productid",
                table: "CartItem",
                column: "Productid");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "CartItem");

            migrationBuilder.DropTable(
                name: "Cart");

            migrationBuilder.DropTable(
                name: "Products");

            migrationBuilder.DropTable(
                name: "AppUsers");
        }
    }
}
