﻿//Add an action listener to the window to run once it finishes loading
window.addEventListener('load', () => {

    //Get all the buttons on the page that have the add-ite-button class on them.
    //This method used is similar to the previus get all commands except it is usabel for fmore then classes.
    let addButtons = document.querySelectorAll(".add-item-button");

    addButtons.forEach((item) => {
        //Get the value field (book id) from the button and convert it to an integer
        let productId = parseInt(item.getAttribute('value'));
        //Add a listener to the current button to run our add to cart method and pass over its productId to the 
        //method when it is called.
        item.addEventListener('click', (e) => addItemToCart(productId));
    });
});

async function addItemToCart(productId) {
    //Sed a fetch requeet top thew shopping cart controller with the productId attached as a query paramater
    let result = await fetch("/Cart/AddToCart?itemId=" + productId)
    //Check the status id of the reponse
    if (result.status == 401) {
        //Redirect the user to the login page
        location.href = "/Authen/UserLogin";
    }
    else if (result.status != 200) {
        //Popup an alert message in the browser
        alert("Something went wrong. Please try again");
    }
    else {
        //Show the updated cart if no errors occured
        showCartModal();
    }
}

async function showProductDetailsModal(id) {
    //Request the partial view from the controller
    var result = await fetch("/Product/Details/" + id);
    //Get the contents of the response as HTML text
    var htmlResult = await result.text();
    //Place the HTML text inside the modal body
    document.getElementById("productModalBody").innerHTML = htmlResult;
    //Tell the model to show itself on screen using JQUERY.
    $("#productModal").modal("show");
}