﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.


//Adds a listener to the browser window to trigger once it has finished loading
window.addEventListener('load', (e) => {
    //Then find the element with the btnTheme id on it add add a listener to the button to 
    //trigger when it is clicked
    document.getElementById('btnTheme').addEventListener('click', (e) => {
        //Run the theme swithcing method
        SwitchTheme();
    });
});

async function SwitchTheme() {
    let currentTheme = localStorage.getItem("Theme")

    //Checks if the current theme has been set or is equal to primary, if so it will change it ot secondary
    //in the local storage.
    if (currentTheme == "Secondary") {
        //Local storage stores data on the user side, similar to a cookie.
        localStorage.setItem("Theme", "Primary");

        //Call the set theme endpoint in our settings controller to update the theme setting.
        let result = await fetch("api/Settings/SetTheme", {
            method: "POST",
            headers: { "content-type": "application/json" },
            body: JSON.stringify(
                {
                    theme: "Primary"
                })
        });
        console.log(result);

        document.getElementById("themeStyle").setAttribute("href", "/css/primary-theme.css");
    }
    else {
        //Local storage stores data on the user side, similar to a cookie.
        localStorage.setItem("Theme", "Secondary");
        //Call the set theme endpoint in our settings controller to update the theme setting.
        let result = await fetch("api/Settings/SetTheme", {
            method: "POST",
            headers: { "content-type": "application/json" },
            body: JSON.stringify(
                {
                    theme: "Secondary"
                })
        });
        console.log(result);

        document.getElementById("themeStyle").setAttribute("href", "/css/secondary-theme.css");
    }
}