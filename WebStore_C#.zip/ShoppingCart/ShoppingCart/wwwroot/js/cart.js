﻿//Add a listener to the form that will run once the page is loaded
window.addEventListener('load', () => {
    //Find the cart modal button using its id and add a listener to run the desired 
    //function when it is pressed.
    document.getElementById('btnCartModal').addEventListener('click', () => showCartModal());
})

async function showCartModal() {
    //Request the shopping cart partial from the cart controller
    var result = await fetch("Cart/Index");
    //If you get the bad request response (nobody logged in)
    if (result.status != 200) {
        //Redirect to the login page
        location.href = "/Authen/UserLogin"
        return;
    }
    //Get the fetch result and convert it to HTML text
    var htmlResult = await result.text();
    //Set the HTML text as the conttent of the modal body
    document.getElementById("cartModalBody").innerHTML = htmlResult;


    overrideQtyToggleForms();
    setupQuantityButtons();
    setupRemoveButtons();
    setupCheckoutAndCancelButtons();

    calculateCartTotal()

    //Open the modal.
    $('#cartModal').modal('show');
}

function overrideQtyToggleForms() {
    //Find all the quanity toggles inside the items in the cart modal
    let itemQtyForms = document.querySelectorAll(".cart-qty-toggle");
    //Loop through all of the forms that were found
    itemQtyForms.forEach((item) => {
        //Add a listener to each form for when it tries to submit
        item.addEventListener('submit', (e) => {
            //Stop the defeult form submit behavior.
            e.preventDefault();
        });
    });
}

async function setupQuantityButtons() {
    //Find all the minus buttons inside the items of the cart modal
    let minusButtons = document.querySelectorAll(".btn-minus");
    //Loop through all of the buttons that were found
    minusButtons.forEach((item) => {
        //Add a listener to each button to trigger the decrese method when clicked
        item.addEventListener('click', (e) => decreaseQuantity(e));
    });

    //Find all the plus buttons inside the items of the cart modal
    let plusButtons = document.querySelectorAll(".btn-plus");
    //Loop through all of the buttons that were found
    plusButtons.forEach((item) => {
        //Add a listener to each button to trigger the decrese method when clicked
        item.addEventListener('click', (e) => increaseQuantity(e));
    });

}

async function decreaseQuantity(e) {
    //Get the cart id by accessing the target of the event trigeer and then going to its parent form
    //to find the first input field and retrieving its value.
    let cartItemid = parseInt(e.target.form.querySelector("input").value);
    //Get the wuantity by finding the qty text field in the buttons form angd retirving its text from 
    //between the tags.
    let qty = parseInt(e.target.form.querySelector(".qty-text").innerText);
    if (qty <= 1) {
        //Rmeove the item instead of setting its qty to 0
        removeItem(cartItemid);
        return;
    }
    else {
        //Decrease the quantity by one
        qty--;
        //Go back to the qty text and update it to the new quantity
        e.target.form.querySelector(".qty-text").innerText = qty;

        recalculateLineTotal(e, qty);
        calculateCartTotal()

        //Pass the quantity and item id to the update quantity method for processing.
        updateQuantity(qty, cartItemid);
    }

}


async function increaseQuantity(e) {
    //Get the cart id by accessing the target of the event trigeer and then going to its parent form
    //to find the first input field and retrieving its value.
    let cartItemid = parseInt(e.target.form.querySelector("input").value);
    //Get the wuantity by finding the qty text field in the buttons form angd retirving its text from 
    //between the tags.
    let qty = parseInt(e.target.form.querySelector(".qty-text").innerText);
    //Increase the quantity by one
    qty++;
    //Go back to the qty text and update it to the new quantity
    e.target.form.querySelector(".qty-text").innerText = qty;

    recalculateLineTotal(e, qty);
    calculateCartTotal()

    //Pass the quantity and item id to the update quantity method for processing.
    updateQuantity(qty, cartItemid);
}

async function recalculateLineTotal(e, qty) {
    //Get the line item field for the current item
    let lineItem = e.target.form.querySelector(".line-total");
    //Get the unit prove for the current itme form the value field
    let unitPrice = parseFloat(lineItem.getAttribute("value"));
    //Calculate the unit price as an integer to avoid floatin point errors 
    let totalPrice = qty * parseInt(unitPrice * 100);
    //Set the new total into the line price and convert it back to a float.
    lineItem.innerText = "Total: $" + parseFloat(totalPrice / 100).toFixed(2);
}

async function calculateCartTotal() {
    //Craete a variable for our running total and set it to 0.00
    let total = 0.00;
    //Find all the line total elements in the cart
    let lineItems = document.querySelectorAll(".line-total");
    //Loop through each of the line total objects
    lineItems.forEach((item) => {
        //Get the price out of the line total text
        let linePrice = parseFloat(item.innerHTML.split("$")[1] * 100);
        //Add the line price to the current running total
        total += linePrice
    })
    //Update the total proice field in the cart modal footer
    document.querySelector("#modalGrandTotal").innerText = "Total: $" + (total / 100).toFixed(2) + "    (Tax Included)";
}

async function updateQuantity(qty, cartItemid) {
    //Create a JS object to hold the 2 values. The names used here need to match your shopping cart model
    let updatedItem = {
        Quantity: qty,
        id: cartItemid
    };

    let reponse = await fetch("/Cart/UpdateQuantity", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updatedItem)
    });

    if (reponse.status != 200) {
        console.log("Update QTY Response:" + reponse.status);
    }

}

async function setupRemoveButtons() {
    //Find all the remove buttons in the cart modal
    let removeButtons = document.querySelectorAll(".remove-button");
    //Cycle through all the buttons
    removeButtons.forEach((item) => {
        //get the cart id our of the value attribute in each button.
        let cartItemid = parseInt(item.getAttribute("value"))
        //Add a listener to each button to trigger the remove method when clicked and pass it
        //the cart item number
        item.addEventListener('click', (e) => removeItem(cartItemid));
    })
}

async function removeItem(cartItemid) {

    let result = await fetch("/Cart/RemoveFromCart?id=" + cartItemid);

    showCartModal();
}

async function setupCheckoutAndCancelButtons() {
    //Finc the checkout button if it is visible
    let checkoutButton = document.querySelector("#btnCheckout");
    //If the button exists, add a listener to run the finalise method.
    if (checkoutButton != null) {
        checkoutButton.addEventListener('click', (e) => finaliseCart(e))
    }

    //Finc the cancel button if it is visible
    let cancelButton = document.querySelector("#btnCancel");
    //If the button exists, add a listener to run the cancel method.
    if (cancelButton != null) {
        cancelButton.addEventListener('click', (e) => cancelCart(e))
    }
}

async function finaliseCart(e) {

    if (confirm("Proceed To Checkout?") == true) {
        //Get the id out of the button tht was pressed
        let id = parseInt(e.target.getAttribute("value"));
        //Pass the id as part of the get request to our controller to trigger the finalise method
        let request = await fetch("/Cart/FinaliseCart/" + id);
        //If the response is a 200 (meaning it worked), close the modal and let the user know.
        if (request.status == 200) {

            $('#cartModal').modal('hide');
            alert("Cart Finalised. Thank you for shopping.")
        }
    }
    else {
        return;
    }
}

async function cancelCart(e) {

    if (confirm("Are You Sure You Want to Cancel?") == true) {
        //Get the id out of the button the was pressed
        let id = parseInt(e.target.getAttribute("value"));
        //Pass the id as part of the get request to our controller to trigger the cancel method
        let request = await fetch("/Cart/CancelCart/" + id);
        //If the response is a 200 (meaning it worked), close the modal and let the user know.
        if (request.status == 200) {

            $('#cartModal').modal('hide');
            alert("Cart Cancelled!")
        }
    }
    else {
        return;
    }
}
