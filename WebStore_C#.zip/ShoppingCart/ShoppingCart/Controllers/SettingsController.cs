﻿using Microsoft.AspNetCore.Mvc;

namespace ShoppingCart.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SettingsController : ControllerBase
    {
        /// <summary>
        /// Recieves the users desired user theme setting and passes it ot the user session to be stored.
        /// </summary>
        /// <param name="setting">The theme object holdingh our settings</param>
        /// <returns>The response id of the event</returns>
        [HttpPost("SetTheme")]
        public async Task<IActionResult> SetTheme([FromBody] UserSettings setting)
        {
            HttpContext.Session.SetString("Theme", setting.Theme);
            return Ok();
        }

        /// <summary>
        /// Model for holding user settings and passing them to the endpoints.
        /// </summary>
        public class UserSettings
        {
            public string Theme { get; set; } = "Primary";
        }
    }
}

