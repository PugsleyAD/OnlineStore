﻿using ShoppingCart.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace ShoppingCart.Controllers
{
    public class CartController : Controller
    {
        public readonly StoreDBContext _context;

        public CartController(StoreDBContext context)
        {
            _context = context;
        }

        public IActionResult History()
        {
            var value = HttpContext.User.FindFirstValue("ID") ?? "-1";  //Retrieve current users ID from Cliam. If null, set to "-1"

            var id = int.Parse(value);      //Convert "ID" to int

            if (id == -1)       //If -1, respond BadRequest
            {
                return BadRequest();
            }

            var shoppingCarts = _context.Carts.Where(c => c.AppUserId == id && c.FinalisedDate != null).ToList();    //Get the latest shopping cart of current user
            if (shoppingCarts != null)       //If a Cart return, Find all cart items
            {
                foreach (var cart in shoppingCarts)
                {
                    cart.CartItems = _context.CartItems.Include(ci => ci.Product)
                                                           .Where(ci => ci.CartId == cart.Id).ToList();
                }

            }
            return View(shoppingCarts);       //Return partial view with data
        }

        public IActionResult Index()
        {
            
            var value = HttpContext.User.FindFirstValue("ID") ?? "-1";  //Retrieve current users ID from Cliam. If null, set to "-1"
            
            var id = int.Parse(value);      //Convert "ID" to int

            if (id == -1)       //If -1, respond BadRequest
            {
                return BadRequest();
            }

            var shoppingCart = _context.Carts.Where(c => c.AppUserId == id && c.FinalisedDate == null).FirstOrDefault();    //Get the latest shopping cart of current user
            if (shoppingCart != null)       //If a Cart return, Find all cart items
            {
                shoppingCart.CartItems = _context.CartItems.Include(ci => ci.Product)
                                                           .Where(ci => ci.CartId == shoppingCart.Id).ToList();
            }

            return PartialView("_ShoppingCartPartial", shoppingCart);       //Return partial view with data
        }

        public async Task<IActionResult> AddToCart(int itemId)
        {
            var value = HttpContext.User.FindFirstValue("ID") ?? "-1";
            var id = int.Parse(value);

            if (id == -1)                   //If no logged in, return an Unauthorised response
            {
                return Unauthorized();
            }
            
            var cart = _context.Carts.Where(c => c.AppUserId == id && c.FinalisedDate == null)  //Retrieve lastest shopping cart with items
                                     .Include(c => c.CartItems).FirstOrDefault();

            var cartItem = new CartItem     //create a cart item if the cart empty
            {
                ProductId = itemId,
                Quantity = 1
            };

            if (cart == null)
            {
                cart = new Cart
                {
                    AppUserId = id,
                    CartItems = new List<CartItem> { cartItem }
                };
                _context.Carts.Add(cart);
            }
            else
            {
                var item = cart.CartItems.Where(ci => ci.ProductId == itemId).FirstOrDefault();    //Check if the desired item is already in the cart
                
                if (item != null)   //If the item already is in the cart
                {
                    item.Quantity++;        //Update the quantity +1
                    
                    _context.CartItems.Attach(item);        //Pass the item to the context class
                    
                    _context.Entry(item).Property(x => x.Quantity).IsModified = true;   //Only update/patch the quantity field
                }

                else    //If the item is not in the cart
                {
                    cartItem.CartId = cart.Id;      //Add the cart Id to the item we created earlier
                    
                    _context.CartItems.Add(cartItem);       //Add it to the database
                }
            }

            _context.SaveChanges();
            return Ok();
        }

        public async Task<IActionResult> UpdateQuantity([FromBody] CartItem item)
        {
            _context.CartItems.Attach(item);    //Pass the item to DB, not automatically call

            _context.Entry(item).Property(i => i.Quantity).IsModified = true;       //Only update/patch the quantity field

            _context.SaveChanges();
            return Ok();
        }

        public async Task<IActionResult> RemoveFromCart(int Id)
        {
            _context.Remove(_context.CartItems.Single(ci => ci.Id == Id));      //Remove item by id

            _context.SaveChanges();
            return Ok();
        }

        public async Task<IActionResult> CancelCart(int id)
        {
            _context.CartItems.RemoveRange(_context.CartItems.Where(ci => ci.CartId == id).ToList());       //Remove item by Cart id

            _context.SaveChanges();
            return Ok();
        }

        public async Task<IActionResult> FinaliseCart(int id)
        {
            var cart = _context.Carts.Where(c => c.Id == id).FirstOrDefault();       //Find the cart that matches the ID
            
            if (cart == null)       //If there was no mathing cart throw an error
            {
                return BadRequest();
            }
           
            cart.Total = CalculateCartTotal(id);         //Update the total cost and data in the cart
            cart.FinalisedDate = DateTime.Now;

            _context.Update(cart);      //Update cart
            _context.SaveChanges();     //UPdate database
            return Ok();
        }

        public double CalculateCartTotal(int id)
        {
            var cartItems = _context.CartItems.Where(ci => ci.CartId == id)     // Get all items in cart
                                              .Include(ci => ci.Product).ToList();

            double total = 0.0f;        // Create and format a variable for total

            foreach (var item in cartItems)     // Loop all items
            {

                total += item.Quantity * item.Product.Price;        // Add up one by one
            }

            return total;
        }

    }
}
