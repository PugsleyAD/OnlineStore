﻿using ShoppingCart.Models;
using ShoppingCart.Models.Repositories;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System.Data;

namespace TypicalTools.Controllers
{
    public class ProductController : Controller
    {
        private readonly IProductRepository _productRepository;

        public ProductController(IProductRepository proRepo)
        {
            _productRepository = proRepo;
        }

        // GET: Product/Index
        public ActionResult Index()
        {
            return View(_productRepository.GetAllProducts());
        }

        public ActionResult ShowSearchResults(string searchPhrase)
        {
            searchPhrase = (string.IsNullOrWhiteSpace(searchPhrase)) ? "" : searchPhrase;   //terniary operator
                                                                                            //x = condition ? true : false

            HttpContext.Session.SetString("LastProductSearch", searchPhrase);   //Store the last search value in the session data (key as "LastProductSearch")

            var products = _productRepository.SearchProducts(searchPhrase); //Retrieve any matching products from the repository and passes them to the index view
            return View("Index", products);     //Create page of searched products
        }

        // GET: ProductController/Details/
        public ActionResult Details(int id)
        {
            return View(_productRepository.GetProductById(id));   //Create detail page of a product
        }

        // GET: ProductController/Create
        public ActionResult CreateProduct()
        {
            string authenticated = HttpContext.Session.GetString("ROLE") ?? "";
            if (!authenticated.Equals("ADMIN"))
            {
                return RedirectToAction("Index", "Home");
            }

            return View();
        }

        // POST: ProductController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CreateProduct(Product product)
        {
            string authenticated = HttpContext.Session.GetString("ROLE") ?? "";
            if (!authenticated.Equals("ADMIN"))
            {
                return RedirectToAction("Index", "Home");
            }

            try
            {
                ModelState.Remove("CartItems");
                if (ModelState.IsValid == false)
                {
                    return View(product);
                }

                _productRepository.CreateProduct(product);
                return RedirectToAction("Index", "Product");
            }
            catch
            {
                return View(product);
            }
        }

        // GET: ProductController/Edit
        public ActionResult EditProduct(int id)
        {
            string authenticated = HttpContext.Session.GetString("ROLE") ?? "";
            if (!authenticated.Equals("ADMIN"))
            {
                return RedirectToAction("Index", "Home");   //Redirect to home page if not ADMIN
            }

            var product = _productRepository.GetProductById(id);

            return View(product);   //Create eidt page of a product
        }

        // POST: ProductController/Edit
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult EditProduct(Product product)
        {
            string authenticated = HttpContext.Session.GetString("ROLE") ?? "";
            if (!authenticated.Equals("ADMIN"))
            {
                return RedirectToAction("Index", "Home");
            }
            try
            {
                if (ModelState.IsValid == false)    //Check whether data received match data model requirements
                {
                    return View();
                }

                _productRepository.EditProduct(product);
                return RedirectToAction("Index", "Product"); //Redirect to edit page of a product
            }
            catch
            {
                return View();
            }
        }

    }
}
