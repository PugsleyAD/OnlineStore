﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using ShoppingCart.Models.Repositories;
using ShoppingCart.Models;
using System.Data;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using System.Security.Claims;

namespace ShoppingCart.Controllers
{
    public class AuthenController : Controller
    {
        private List<Roles> initialRoleList = Enum.GetValues(typeof(Roles)).Cast<Roles>().ToList(); //Get roles from Enum Roles to create a list

        private readonly IAuthenRepository _repository;  //Realize a IAdminRepository

        public AuthenController(IAuthenRepository repository)
        {
            _repository = repository;   //Construct the AdminController
        }


        [HttpGet]
        public IActionResult UserLogin([FromQuery] string ReturnUrl)
        {
            LoginDTO loginDTO = new LoginDTO    //Login URL object holds Return URl 
            {
                ReturnUrl = String.IsNullOrWhiteSpace(ReturnUrl) ? "/Home" : ReturnUrl
            };
            
            return View(loginDTO);      //Pass the return URL to the view and return it to the user
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult UserLogin(LoginDTO loginDTO)
        {

            if (ModelState.IsValid == false)    //model state check
            {
                return View();

            }


            var user = _repository.Authenticate(loginDTO);      //LoginDTO in, AppUser Out
            if (user == null)
            {
                ViewBag.LoginMessage = "Username or Password incorrect!";
                return View();
            }

            var claims = new List<Claim>        //A series of claims, claims=attributes from Object's properties (Object=AppUser)
            {
                new Claim(ClaimTypes.Name, user.UserName),
                new Claim("ROLE", user.Role.ToString()),
                
                new Claim("ID", user.Id.ToString())     //Add the user ID as a claim that can be retrieved for the shopping cart.
            };

            HttpContext.Session.SetString("ROLE", user.Role.ToString());    //Set "ROLE", pass to view
            
            var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme); //Create a claim identity(user object) for login

            var authProperties = new AuthenticationProperties       //Set custom properties, can override the defaults of the auth cookie
            {
                AllowRefresh = true,    //override the sliding expiration

                IsPersistent = true,        //the cookie persit over multiple requests, not just the next one

                RedirectUri = loginDTO.ReturnUrl        //Redirect Url after login
            };
            
            HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme,
                                    new ClaimsPrincipal(claimsIdentity), authProperties);   //Login the user, and store login details to cookie

            return Redirect(loginDTO.ReturnUrl);

        }

        public IActionResult Logoff()
        {
            HttpContext.SignOutAsync();     //Log off, clear their authentication cookie and session
            HttpContext.Session.SetString("ROLE", "");
            return RedirectToAction("Index", "Home");
        }

        public IActionResult CreateUser()
        {
            string authenticated = HttpContext.Session.GetString("ROLE") ?? "";   //Store authentication status to a string

            if (authenticated == "CUSTOMER")
            {
                return RedirectToAction("Index", "Home");   //Redirect to Home page with ADMIN role

            }

            SetupComboBoxData();    //Set up a combobox for creating new user

            return View();  //Create page for creating user
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult CreateUser(CreateUserDTO userDTO)
        {
            string authenticated = HttpContext.Session.GetString("ROLE") ?? "";   //Store authentication status to a string

            if (authenticated == "CUSTOMER")
            {
                return RedirectToAction("Index", "Home");   //Redirect to Home page with ADMIN role

            }
            try
            {
                if (ModelState.IsValid == false || (userDTO.Role != Roles.ADMIN && userDTO.Role != Roles.CUSTOMER))    //model state check
                {
                    ViewBag.CreateUserMessage = "Please select a Role!";    //Check whether a specific role selected
                    SetupComboBoxData();
                    return View(userDTO);
                }

                if (userDTO.Password.Equals(userDTO.PasswordConfirmation) == false)
                {
                    ViewBag.CreateUserMessage = "Password and Password Confirmation do not match!"; //Check whether Passwords matched
                    SetupComboBoxData();
                    return View(userDTO);
                }

                var user = _repository.CreateUser(userDTO); //Create a user

                if (user == null)
                {
                    ViewBag.CreateUserMessage = "UserName already exists!"; //Check whether UserName exists
                    SetupComboBoxData();
                    return View(userDTO);
                }

                ViewBag.CreateUserMessage = "User Created!";    //Pop up message show user created
                SetupComboBoxData();
                return View();
            }
            catch
            {
                SetupComboBoxData();
                return View(userDTO);
            }
        }

        private void SetupComboBoxData()
        {
            string authenticated = HttpContext.Session.GetString("ROLE") ?? "";   //Store authentication status to a string

            var castedRoleList = new List<SelectListItem>();    //A List stores roles

            if (authenticated == "ADMIN")
            {
                foreach (var r in initialRoleList)
                {
                    castedRoleList.Add(new SelectListItem() //Add roles to List from Enum Roles
                    {
                        Text = r.ToString(),    //Transfer Text showed
                        Value = ((int)r).ToString() //Transfer idex to use
                    });
                }
            }
            else
            {
                castedRoleList.Add(new SelectListItem() //Add roles to List from Enum Roles
                {
                    Text = "CUSTOMER",    //Transfer Text showed
                    Value = "0" //Transfer idex to use
                });
            }
            

            ViewBag.Roles = castedRoleList; //Transfer role list to ViewBag


        }
    }
}
