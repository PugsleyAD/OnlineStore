﻿namespace ShoppingCart.Models
{
    public class Cart
    {
        public int Id { get; set; }
        public int AppUserId { get; set; }
        public DateTime? FinalisedDate { get; set; }
        public double Total { get; set; }

        //Linking reference to the user model for this cart.
        public virtual AppUser User { get; set; }
        public virtual List<CartItem> CartItems { get; set; }
    }
}
