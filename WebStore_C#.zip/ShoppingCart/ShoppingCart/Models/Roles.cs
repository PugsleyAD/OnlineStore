﻿namespace ShoppingCart.Models
{
    public enum Roles
    {
        ADMIN = 1,
        CUSTOMER = 0
    }
}
