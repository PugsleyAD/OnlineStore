﻿namespace ShoppingCart.Models.Repositories
{
    public interface IAuthenRepository
    {
        AppUser Authenticate(LoginDTO loginDTO);
        AppUser CreateUser(CreateUserDTO userDTO);
    }
}
