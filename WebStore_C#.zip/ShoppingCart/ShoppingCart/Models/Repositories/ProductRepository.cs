﻿using Microsoft.EntityFrameworkCore;
using ShoppingCart.Models.Repositories;
using ShoppingCart.Models;

namespace ShoppingCart.Models.Repositories

{
    public class ProductRepository : IProductRepository
    {
        private readonly StoreDBContext _context;  //Context work with database
        public ProductRepository(StoreDBContext context)
        {
            _context = context; //Conutract the product repositroy
        }
        public void CreateProduct(Product product)
        {
            _context.Products.Add(product);
            _context.SaveChanges(); //Add a product and save changes in the database
        }

        public List<Product> GetAllProducts()
        {
            return _context.Products.ToList(); //View all products in the database
        }

        public Product GetProductById(int id)
        {
            return _context.Products.Where(p => p.ProductId == id)
                                    .FirstOrDefault() ?? new Product(); //View a product with id matched
        }

        public List<Product> SearchProducts(string searchPhrase)
        {
            return _context.Products.Where(p => p.ProductName.ToLower().Contains(searchPhrase.ToLower())).ToList(); //View products with name matched phrase provided
        }

        public void EditProduct(Product product)
        {
            _context.Products.Update(product);
            _context.SaveChanges(); //Update a product and save
        }

    }
}

