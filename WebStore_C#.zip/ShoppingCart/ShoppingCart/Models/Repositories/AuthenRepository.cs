﻿using Microsoft.AspNetCore.Http;

namespace ShoppingCart.Models.Repositories
{
    public class AuthenRepository : IAuthenRepository
    {
        private readonly StoreDBContext _context;
        public AuthenRepository(StoreDBContext context)
        {
            _context = context;
        }
        public AppUser Authenticate(LoginDTO loginDTO)
        {
            var userDetails = _context.AppUsers.Where(u => u.UserName.Equals(loginDTO.UserName))    //Look for a user in the database that matches the provided username
                                               .FirstOrDefault();

            if (userDetails == null)
            {
                return null;    //If no user doesn't exists, exit the method and retrun null
            }

            if (BCrypt.Net.BCrypt.EnhancedVerify(loginDTO.Password, userDetails.PasswordHash))
            {
                return userDetails;  //Check the user login provided matches the one used to generate the hash
            }

            return null;    //If the password was wrong, return null
        }

        public AppUser CreateUser(CreateUserDTO userDTO)
        {
            var userDetails = _context.AppUsers.Where(u => u.UserName.Equals(userDTO.UserName))  //Look for a user in the database that matches the provided username
                                               .FirstOrDefault();

            if (userDetails != null)
            {
                return null;    //If user exists, exit the method and retrun null
            }

            AppUser user = new AppUser  //Create a new ApiUser object using the details from the dto
            {
                UserName = userDTO.UserName,
                PasswordHash = BCrypt.Net.BCrypt.EnhancedHashPassword(userDTO.Password),
                Role = userDTO.Role
            };

            _context.AppUsers.Add(user);
            _context.SaveChanges();
            return user;    //Add the new user to the database and return the new user
        }
    }
}
