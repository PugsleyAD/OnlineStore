﻿using System.ComponentModel.DataAnnotations;
using System.Data;

namespace ShoppingCart.Models
{
    public class AppUser
    {
        public int Id { get; set; }
        public string UserName { get; set; } = string.Empty;
        public string PasswordHash { get; set; } = string.Empty;
        public Roles Role { get; set; } //= Roles.CUSTOMER;
        public virtual List<Cart> Carts { get; set; }     //Linking reference to the shopping cart model
    }
}
