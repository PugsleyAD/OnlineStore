﻿using System.ComponentModel.DataAnnotations;

namespace ShoppingCart.Models
{
    public class LoginDTO
    {
        public string UserName { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
        public string ReturnUrl { get; set; }
    }
}
