﻿using System.ComponentModel.DataAnnotations;

namespace ShoppingCart.Models
{
    public class CreateUserDTO
    {
        [EmailAddress(ErrorMessage = "Please enter a valid email address.")]
        public string UserName { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
        public string PasswordConfirmation { get; set; } = string.Empty;
        public Roles Role { get; set; } = 0;
    }
}

