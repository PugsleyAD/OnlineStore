﻿using BCrypt.Net;
using Microsoft.EntityFrameworkCore;
using ShoppingCart.Models;

namespace ShoppingCart.Models
{
    public class StoreDBContext : DbContext
    {

        List<Product> _productList;

        public DbSet<Product> Products { get; set; }
        public DbSet<AppUser> AppUsers { get; set; }
        public DbSet<Cart> Carts { get; set; }
        public DbSet<CartItem> CartItems { get; set; }

        public StoreDBContext(DbContextOptions options) : base(options)
        {
            _productList = new List<Product>(); //Look for products from the database

            string[] productLines = File.ReadAllLines("./wwwroot/Data/Products.csv");   //Load products in the CSV

            foreach (var product in productLines)
            {
                string[] productSections = product.Split(',');  //Use , to split each line from CSV

                Product parsedProduct = new Product //Create each product
                {
                    ProductId = int.Parse(productSections[0]),
                    ProductName = productSections[1],
                    Unit = productSections[2],
                    Price = float.Parse(productSections[3])
                };

                _productList.Add(parsedProduct);    //Add each product to the Plist
            };
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            foreach (var p in _productList) //Add products from CSV to database
            {
                modelBuilder.Entity<Product>().HasData(
                    new Product
                    {
                        ProductId = p.ProductId,
                        ProductName = p.ProductName,
                        Unit = p.Unit,
                        Price = p.Price
                    }
                    );
            }

            modelBuilder.Entity<AppUser>().HasData(
            new AppUser   //Create and Add a user with following details
              {
                  Id = 1,
                  UserName = "admin",
                  PasswordHash = BCrypt.Net.BCrypt.EnhancedHashPassword("admin"),
                  Role = Roles.ADMIN
            });

            modelBuilder.Entity<Cart>().HasData(
               new Cart
               {
                   Id = 1,
                   AppUserId = 1,
                   FinalisedDate = null,
                   Total = 27.98
               });

            modelBuilder.Entity<CartItem>().HasData(
                new CartItem
                {
                    Id = 1,
                    CartId = 1,
                    ProductId = 1,
                    Quantity = 1
                },
                new CartItem
                {
                    Id = 2,
                    CartId = 1,
                    ProductId = 2,
                    Quantity = 2
                });

            base.OnModelCreating(modelBuilder);
        }
    }
}


