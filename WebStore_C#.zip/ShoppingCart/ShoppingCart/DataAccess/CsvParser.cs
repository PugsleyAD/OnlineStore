﻿
using ShoppingCart.Models;

namespace ShoppingCart.DataAccess
{
    public class CsvParser
    {
        private IWebHostEnvironment _hostingEnvironment;
        public CsvParser(IWebHostEnvironment environment)
        {
            _hostingEnvironment = environment;
        }

        public List<Product> ParseProducts()
        {
            string wwwRootPath = _hostingEnvironment.WebRootPath;

            string[] productLines = File.ReadAllLines(wwwRootPath + "wwwroot\\Data\\Products.csv");

            List<Product> productList = new List<Product>();

            foreach (var product in productLines)
            {
                string[] productSections = product.Split(',');

                Product parsedProduct = new Product
                {
                    ProductId = int.Parse(productSections[0]),
                    ProductName = productSections[1],
                    Unit = productSections[2],
                    Price = float.Parse(productSections[3])
                };

                productList.Add(parsedProduct);
            }
            return productList;
        }

        public Product GetSingleProduct(int id)
        {
            var products = ParseProducts();

            return products.Where(p => p.ProductId == id).FirstOrDefault();
        }
    } 
}