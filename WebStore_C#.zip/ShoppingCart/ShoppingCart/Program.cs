using ShoppingCart.Models;
using ShoppingCart.Models.Repositories;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.EntityFrameworkCore;
using ShoppingCart.Models.Repositories;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();     // Add services to the container

var connectionString = builder.Configuration.GetConnectionString("Default");        //Get connection string from the appsettings.json

builder.Services.AddDbContext<StoreDBContext>(options => {    //Adds our Context Class to the services container to use dependency injection system
    options.UseSqlServer(connectionString);
});
//Adds the repositories to the dependency injection system so they
//can be requested by other classes by using their interface name. 
builder.Services.AddScoped<IProductRepository, ProductRepository>();
builder.Services.AddScoped<IAuthenRepository, AuthenRepository>();

//Adds the ability to use session data to your web aopplicaiotn and configures any required settings
//for storing and managing the data.
builder.Services.AddSession(options =>
{
    //Sets the maximum time the user can be idle between requests before the session expires.
    options.IdleTimeout = TimeSpan.FromMinutes(10);
    //Makes the session cookie only usable through http and cannot be accessed by client side
    //scripts (Javascript)
    options.Cookie.HttpOnly = true;
    //Sets rules about whether the cookie can be used outside the domain it was created.
    options.Cookie.SameSite = SameSiteMode.Strict;
    //Sets rules about whether the cookie must be sent by HTTP or HTTPS or via the same method
    //as the request.
    options.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
    //Checks whether the cookie is required for the site to properly operate.
    options.Cookie.IsEssential = true;
});

builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
                .AddCookie(options =>
                {
                    //Sets the defualt login page for whenever a login redirection is needed
                    options.LoginPath = "/Authen/Login";
                    //Sets the defualt login page for whenever a access denied redirection is needed
                    options.AccessDeniedPath = "/Authen/AccessDenied";
                    //Sets the time before the login expires
                    options.ExpireTimeSpan = TimeSpan.FromMinutes(10);
                    //Resets the expiry if used and has less than half time left.
                    options.SlidingExpiration = true;
                });


var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseSession();

//The UseAuthentication is needed for the login cookie to work.
//It also needs to go before the UseAuthentication and after the UseRouting to work.
app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
